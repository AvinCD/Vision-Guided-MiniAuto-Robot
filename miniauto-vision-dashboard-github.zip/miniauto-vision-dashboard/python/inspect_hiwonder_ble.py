import asyncio
from bleak import BleakClient

BLE_ADDRESS = "48:87:2D:82:8A:74"

async def main():
    async with BleakClient(BLE_ADDRESS, timeout=12) as client:
        print("Connected:", client.is_connected)
        for service in client.services:
            print("SERVICE:", service.uuid)
            for char in service.characteristics:
                print(
                    "  HANDLE:", char.handle,
                    "| UUID:", char.uuid,
                    "| PROPERTIES:", char.properties,
                )

asyncio.run(main())
