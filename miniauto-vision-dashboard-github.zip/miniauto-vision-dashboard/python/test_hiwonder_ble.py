import asyncio
from bleak import BleakClient

# Change these values if you use a different robot / BLE channel.
BLE_ADDRESS = "48:87:2D:82:8A:74"
BLE_CONTROL_HANDLE = 24

async def send(client, command):
    print("Sending:", command)
    await client.write_gatt_char(
        BLE_CONTROL_HANDLE,
        command.encode("utf-8"),
        response=False,
    )
    await asyncio.sleep(0.5)

async def main():
    async with BleakClient(BLE_ADDRESS, timeout=12) as client:
        print("Connected:", client.is_connected)
        await send(client, "S|$")
        await send(client, "C|35|$")
        await send(client, "A|2|$")
        await asyncio.sleep(2)
        await send(client, "A|8|$")
        print("Test complete.")

asyncio.run(main())
