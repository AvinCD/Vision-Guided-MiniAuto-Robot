import asyncio
import queue
import threading
import time

import cv2
import numpy as np
import requests
from bleak import BleakClient
from flask import Flask, Response, jsonify, render_template_string

# ============================================================
# MINIAUTO VISION DASHBOARD — BLE VERSION
# ============================================================
# Change only these values when needed.
ESP32_IP = "192.168.1.220"  # Change when ESP32 gets a new IP
ESP32_STREAM_URL = f"http://{ESP32_IP}:81/stream"

BLE_ADDRESS = "48:87:2D:82:8A:74"  # Your Hiwonder BLE address
BLE_CONTROL_HANDLE = 24   # Confirmed working Hiwonder BLE channel

ROBOT_SPEED = 35
MIN_OBJECT_AREA = 1800
CENTER_DEADZONE = 65
STOP_AREA = 18000
SEND_INTERVAL = 0.08

app = Flask(__name__)

# Shared state
camera_lock = threading.Lock()
latest_frame = None
camera_ok = False
camera_error = ""

ble_connected = False
autonomy_enabled = False
action_text = "STOPPED"
last_command = ""
last_send_time = 0.0

command_queue = queue.Queue(maxsize=50)


# ============================================================
# COMMANDS
# ============================================================
def queue_command(command, label=None, force=False):
    """Queue one Hiwonder command for the BLE worker."""
    global last_command, last_send_time, action_text

    now = time.time()
    if not force and command == last_command and (now - last_send_time) < SEND_INTERVAL:
        return

    last_command = command
    last_send_time = now

    if label:
        action_text = label

    try:
        command_queue.put_nowait(command)
    except queue.Full:
        # Keep the system responsive; discard the oldest command.
        try:
            command_queue.get_nowait()
        except queue.Empty:
            pass
        try:
            command_queue.put_nowait(command)
        except queue.Full:
            pass


def hard_stop():
    global autonomy_enabled, action_text
    autonomy_enabled = False
    queue_command("S|$", "EMERGENCY STOP", force=True)
    queue_command("A|8|$", "STOPPED", force=True)


# ============================================================
# BLE BACKGROUND WORKER
# ============================================================
async def ble_worker_async():
    global ble_connected, action_text

    while True:
        try:
            print(f"Connecting to Hiwonder BLE: {BLE_ADDRESS}")

            async with BleakClient(BLE_ADDRESS, timeout=12) as client:
                ble_connected = client.is_connected
                print("BLE connected:", ble_connected)

                # Safety on connection
                await client.write_gatt_char(
                    BLE_CONTROL_HANDLE, b"S|$", response=False
                )
                await asyncio.sleep(0.15)
                await client.write_gatt_char(
                    BLE_CONTROL_HANDLE,
                    f"C|{ROBOT_SPEED}|$".encode(),
                    response=False,
                )

                while client.is_connected:
                    # Wait without blocking Flask/camera threads.
                    command = await asyncio.to_thread(command_queue.get)

                    try:
                        await client.write_gatt_char(
                            BLE_CONTROL_HANDLE,
                            command.encode("utf-8"),
                            response=False,
                        )
                        print("BLE sent:", command)
                    except Exception as exc:
                        print("BLE write failed:", exc)
                        action_text = "BLE WRITE FAILED"
                        break

        except Exception as exc:
            ble_connected = False
            action_text = "BLE RECONNECTING"
            print("BLE reconnecting:", exc)
            await asyncio.sleep(2)


def ble_worker_thread():
    asyncio.run(ble_worker_async())


# ============================================================
# CAMERA BACKGROUND WORKER
# ============================================================
def camera_worker():
    global latest_frame, camera_ok, camera_error

    while True:
        response = None
        try:
            print("Connecting to camera:", ESP32_STREAM_URL)
            response = requests.get(
                ESP32_STREAM_URL,
                stream=True,
                timeout=(5, 20),
            )

            if response.status_code != 200:
                raise RuntimeError(f"Camera HTTP status {response.status_code}")

            camera_ok = True
            camera_error = ""
            buffer = b""

            for chunk in response.iter_content(chunk_size=4096):
                if not chunk:
                    continue

                buffer += chunk
                newest = None

                # Decode all complete frames available and keep only newest.
                while True:
                    start = buffer.find(b"\xff\xd8")
                    end = buffer.find(b"\xff\xd9", start + 2)

                    if start == -1 or end == -1:
                        break

                    jpg = buffer[start:end + 2]
                    buffer = buffer[end + 2:]

                    frame = cv2.imdecode(
                        np.frombuffer(jpg, dtype=np.uint8),
                        cv2.IMREAD_COLOR,
                    )
                    if frame is not None:
                        newest = frame

                if newest is not None:
                    with camera_lock:
                        latest_frame = newest

        except Exception as exc:
            camera_ok = False
            camera_error = str(exc)
            print("Camera reconnecting:", exc)
            time.sleep(2)
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass


# ============================================================
# RED TARGET AUTONOMY
# ============================================================
def process_autonomy(frame):
    global action_text

    height, width = frame.shape[:2]
    frame_center_x = width // 2

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    lower_red_1 = np.array([0, 120, 70])
    upper_red_1 = np.array([10, 255, 255])
    lower_red_2 = np.array([170, 120, 70])
    upper_red_2 = np.array([180, 255, 255])

    mask = cv2.inRange(hsv, lower_red_1, upper_red_1)
    mask |= cv2.inRange(hsv, lower_red_2, upper_red_2)

    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=2)

    contours, _ = cv2.findContours(
        mask,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE,
    )

    cv2.line(
        frame,
        (frame_center_x, 0),
        (frame_center_x, height),
        (255, 255, 255),
        2,
    )

    if not contours:
        queue_command("A|8|$", "TARGET LOST — STOP")
        return frame

    largest = max(contours, key=cv2.contourArea)
    area = cv2.contourArea(largest)

    if area < MIN_OBJECT_AREA:
        queue_command("A|8|$", "TARGET TOO SMALL")
        return frame

    x, y, w, h = cv2.boundingRect(largest)
    object_center_x = x + w // 2
    error_x = object_center_x - frame_center_x

    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
    cv2.circle(frame, (object_center_x, y + h // 2), 6, (255, 0, 0), -1)

    cv2.putText(
        frame,
        f"area={int(area)} error={error_x}",
        (18, height - 16),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,
        (255, 255, 255),
        1,
    )

    if area > STOP_AREA:
        queue_command("A|8|$", "TARGET CLOSE — STOP")
    elif error_x < -CENTER_DEADZONE:
        queue_command("A|9|$", "ALIGN LEFT")
    elif error_x > CENTER_DEADZONE:
        queue_command("A|10|$", "ALIGN RIGHT")
    else:
        queue_command("A|2|$", "FORWARD — TRACKING")

    return frame


# ============================================================
# VIDEO FEED
# ============================================================
def generate_video():
    while True:
        with camera_lock:
            frame = None if latest_frame is None else latest_frame.copy()

        if frame is None:
            frame = np.zeros((360, 640, 3), dtype=np.uint8)
            cv2.putText(
                frame,
                "Waiting for ESP32-S3 camera...",
                (40, 185),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.75,
                (255, 255, 255),
                2,
            )
        else:
            if autonomy_enabled:
                frame = process_autonomy(frame)

            cv2.putText(
                frame,
                action_text,
                (18, 34),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.72,
                (0, 255, 255),
                2,
            )

        ok, encoded = cv2.imencode(".jpg", frame)
        if ok:
            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n\r\n"
                + encoded.tobytes()
                + b"\r\n"
            )

        time.sleep(0.03)


# ============================================================
# WEB PAGE
# ============================================================
PAGE = r"""
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MiniAuto Vision Dashboard</title>
<style>
:root{
 --bg:#09111f;--panel:#111d30;--panel2:#16263f;--text:#eaf2ff;
 --muted:#a0b2cb;--blue:#1d8cff;--green:#20bd76;--red:#ec4d57;--orange:#ef9a3d;
}
*{box-sizing:border-box}
body{margin:0;font-family:Arial,sans-serif;color:var(--text);
background:radial-gradient(circle at top,#1b3157 0,var(--bg) 48%)}
.wrap{max-width:1160px;margin:auto;padding:18px}
h1{margin:0 0 5px;font-size:28px}.sub{color:var(--muted);margin-bottom:16px}
.grid{display:grid;grid-template-columns:1.65fr 1fr;gap:16px}
.card{background:rgba(17,29,48,.95);border:1px solid #294562;border-radius:16px;
padding:14px;box-shadow:0 10px 25px rgba(0,0,0,.24)}
.video{width:100%;display:block;border-radius:10px;background:#000}
.status{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px}
.tile{background:var(--panel2);border-radius:10px;padding:10px}
.label{font-size:12px;color:var(--muted);text-transform:uppercase}
.value{font-size:16px;font-weight:bold;margin-top:4px}
.controls{display:grid;grid-template-columns:repeat(3,1fr);gap:9px;max-width:330px;margin:auto}
button{border:0;border-radius:10px;padding:14px 10px;cursor:pointer;font-weight:bold;
color:white;background:#253b5a;font-size:15px}
button:hover{filter:brightness(1.13)}.forward{background:var(--blue)}
.stop{background:var(--red)}.auto{background:var(--green)}.warn{background:var(--orange)}
.wide{grid-column:span 3}.hint{color:var(--muted);font-size:13px;line-height:1.45;margin-top:14px}
@media(max-width:850px){.grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="wrap">
<h1>MiniAuto Vision Dashboard</h1>
<div class="sub">ESP32-S3 camera · Hiwonder BLE control · Red-target autonomy</div>
<div class="grid">
<section class="card">
  <img class="video" src="/video_feed" alt="Live camera feed">
  <div class="hint">Close other Python vision scripts before starting this dashboard.</div>
</section>
<section class="card">
  <div class="status">
    <div class="tile"><div class="label">Autonomy</div><div id="autonomy" class="value">—</div></div>
    <div class="tile"><div class="label">Camera</div><div id="camera" class="value">—</div></div>
    <div class="tile"><div class="label">BLE Robot</div><div id="robot" class="value">—</div></div>
    <div class="tile"><div class="label">Action</div><div id="action" class="value">—</div></div>
  </div>
  <div class="controls">
    <div></div><button class="forward" onclick="manual('forward')">▲<br>Forward</button><div></div>
    <button onclick="manual('left')">◀<br>Left</button>
    <button class="stop" onclick="manual('stop')">■<br>Stop</button>
    <button onclick="manual('right')">▶<br>Right</button>
    <div></div><button onclick="manual('backward')">▼<br>Backward</button><div></div>
    <button class="auto wide" onclick="autonomy(true)">Start Autonomy</button>
    <button class="warn wide" onclick="autonomy(false)">Stop Autonomy</button>
    <button class="stop wide" onclick="emergency()">EMERGENCY STOP</button>
  </div>
  <div class="hint">Keyboard: Arrow keys move · Space stops · A starts autonomy · X stops autonomy.</div>
</section>
</div>
</div>
<script>
async function post(url){try{await fetch(url,{method:'POST'})}catch(e){console.log(e)}}
function manual(x){post('/manual/'+x)}
function autonomy(on){post(on?'/autonomy/start':'/autonomy/stop')}
function emergency(){post('/emergency')}
async function status(){
 try{
  const s=await (await fetch('/status')).json();
  document.getElementById('autonomy').textContent=s.autonomy?'RUNNING':'OFF';
  document.getElementById('camera').textContent=s.camera_ok?'CONNECTED':'OFFLINE';
  document.getElementById('robot').textContent=s.ble_connected?'CONNECTED':'RECONNECTING';
  document.getElementById('action').textContent=s.action;
 }catch(e){}
}
setInterval(status,500);status();
document.addEventListener('keydown',(e)=>{
 if(e.repeat)return;
 if(e.key==='ArrowUp'){e.preventDefault();manual('forward')}
 if(e.key==='ArrowDown'){e.preventDefault();manual('backward')}
 if(e.key==='ArrowLeft'){e.preventDefault();manual('left')}
 if(e.key==='ArrowRight'){e.preventDefault();manual('right')}
 if(e.key===' '){e.preventDefault();manual('stop')}
 if(e.key.toLowerCase()==='a')autonomy(true);
 if(e.key.toLowerCase()==='x')autonomy(false);
});
</script>
</body>
</html>
"""


# ============================================================
# ROUTES
# ============================================================
@app.get("/")
def index():
    return render_template_string(PAGE)


@app.get("/video_feed")
def video_feed():
    return Response(
        generate_video(),
        mimetype="multipart/x-mixed-replace; boundary=frame",
    )


@app.get("/status")
def status():
    return jsonify(
        autonomy=autonomy_enabled,
        camera_ok=camera_ok,
        camera_error=camera_error,
        ble_connected=ble_connected,
        action=action_text,
    )


@app.post("/manual/<action>")
def manual(action):
    global autonomy_enabled
    autonomy_enabled = False

    mapping = {
        "forward": ("A|2|$", "MANUAL FORWARD"),
        "backward": ("A|6|$", "MANUAL BACKWARD"),
        "left": ("A|9|$", "MANUAL LEFT"),
        "right": ("A|10|$", "MANUAL RIGHT"),
    }

    if action == "stop":
        hard_stop()
        return jsonify(ok=True)

    if action not in mapping:
        return jsonify(ok=False, error="Unknown action"), 400

    cmd, label = mapping[action]
    queue_command(cmd, label, force=True)
    return jsonify(ok=True)


@app.post("/autonomy/start")
def autonomy_start():
    global autonomy_enabled, action_text
    queue_command(f"C|{ROBOT_SPEED}|$", "AUTONOMY STARTED", force=True)
    autonomy_enabled = True
    return jsonify(ok=True)


@app.post("/autonomy/stop")
def autonomy_stop():
    hard_stop()
    return jsonify(ok=True)


@app.post("/emergency")
def emergency():
    hard_stop()
    return jsonify(ok=True)


if __name__ == "__main__":
    print("Starting MiniAuto dashboard...")
    print("Open: http://127.0.0.1:5000")

    threading.Thread(target=ble_worker_thread, daemon=True).start()
    threading.Thread(target=camera_worker, daemon=True).start()

    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
