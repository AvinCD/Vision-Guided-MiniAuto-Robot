# ESP32-S3 Camera Notes

This project uses an ESP32-S3 camera board as the onboard camera. The laptop dashboard reads the MJPEG stream over Wi-Fi.

## Required camera setup

- Use the ESP32-S3 camera sketch that successfully produces the browser stream.
- Keep the camera and laptop on the same Wi-Fi network.
- Note the ESP32 IP address shown in Serial Monitor after boot.
- Update `ESP32_IP` in `python/miniauto_vision_dashboard_ble.py` whenever that IP changes.

## Stream URL

```text
http://<ESP32_IP>:81/stream
```

## Important settings used during testing

```cpp
config.pixel_format = PIXFORMAT_RGB565;
config.frame_size = FRAMESIZE_240X240;
config.grab_mode = CAMERA_GRAB_LATEST;
config.fb_count = 2;
```

The project dashboard uses a manual MJPEG reader because OpenCV's direct `VideoCapture()` stream path was less reliable for this camera setup.
